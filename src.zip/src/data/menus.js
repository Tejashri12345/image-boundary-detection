export const menus = [
    {
        id:1,
        name:`Home`,
        link:`/`
    },
    {
        id:2,
        name:``,
        link:`/blogs`
    },
    {
        id:3,
        name:``,
        link:`/about`
    },
    {
        id:4,
        name:``,
        link:`/contact`
    },

]