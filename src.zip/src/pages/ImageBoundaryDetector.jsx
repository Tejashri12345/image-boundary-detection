import React, { useRef, useEffect, useState } from 'react';
import * as cocoSsd from '@tensorflow-models/coco-ssd';
import '@tensorflow/tfjs';

const ImageBoundaryDetector = () => {
  const [imageData, setImageData] = useState(null);
  const imageRef = useRef();
  const canvasRef = useRef();

  useEffect(() => {
    const storedImage = localStorage.getItem('uploadedImage');
    if (storedImage) {
      setImageData(storedImage);
    }
  }, []);

  useEffect(() => {
    if (imageData) {
      detectObjects();
    }
  }, [imageData]);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();

    reader.onloadend = () => {
      const base64 = reader.result;
      setImageData(base64);
      localStorage.setItem('uploadedImage', base64);
    };

    if (file) {
      reader.readAsDataURL(file);
    }
  };

  const detectObjects = async () => {
    const model = await cocoSsd.load();
    const img = imageRef.current;
    const predictions = await model.detect(img);
    drawBoundingBoxes(predictions);
  };

  const drawBoundingBoxes = (predictions) => {
    const ctx = canvasRef.current.getContext('2d');
    const img = imageRef.current;
    canvasRef.current.width = img.width;
    canvasRef.current.height = img.height;

    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    ctx.drawImage(img, 0, 0);

    predictions.forEach((prediction) => {
      const [x, y, width, height] = prediction.bbox;
      ctx.strokeStyle = 'red';
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, width, height);

      ctx.fillStyle = 'red';
      ctx.font = '16px Arial';
      ctx.fillText(prediction.class, x, y > 10 ? y - 5 : 10);
    });
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Image Upload & Boundary Detection</h2>
      <input type="file" accept="image/*" onChange={handleImageUpload} className="mb-4" />
      {imageData && (
        <div className="relative">
          <img ref={imageRef} src={imageData} alt="Uploaded" onLoad={detectObjects} style={{ display: 'none' }} />
          <canvas ref={canvasRef} className="border shadow-md rounded" />
        </div>
      )}
    </div>
  );
};

export default ImageBoundaryDetector;
